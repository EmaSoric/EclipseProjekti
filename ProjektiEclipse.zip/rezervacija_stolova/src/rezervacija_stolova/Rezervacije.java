package rezervacija_stolova;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.awt.event.ActionEvent;
import java.io.IOException;//dodali
import java.io.FileWriter;//dodali
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;//dodali
import javax.swing.table.DefaultTableModel;

public class Rezervacije {

	JFrame frame;
	public JTextField brstola;
	public JTextField datrez;
	public JTextField imerez;
	public JTextField brosoba;
	public JTextField vrijeme;
	public JTable tab;
	String imerezs, datrezs, brosobas, brstolas, rezervirajs, vrijemes, konobar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rezervacije window = new Rezervacije();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Rezervacije() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.BLACK);
		frame.setBackground(Color.BLUE);
		frame.getContentPane().setBackground(new Color(215, 234, 234));
		frame.setBounds(100, 100, 633, 465);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setSize(1000,500);
		frame.setLocationRelativeTo(null);
		
		JLabel lblNewLabel_1 = new JLabel("Br. stola");
		lblNewLabel_1.setFont(new Font("Yu Gothic", Font.BOLD, 12));
		lblNewLabel_1.setBounds(703, 106, 61, 26);
		frame.getContentPane().add(lblNewLabel_1);
		
		brstola = new JTextField();
		brstola.setBounds(703, 143, 24, 20);
		frame.getContentPane().add(brstola);
		brstola.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Datum rezervacije");
		lblNewLabel_2.setFont(new Font("Yu Gothic", Font.BOLD, 12));
		lblNewLabel_2.setBackground(SystemColor.info);
		lblNewLabel_2.setBounds(73, 106, 131, 26);
		frame.getContentPane().add(lblNewLabel_2);
		
		datrez = new JTextField();
		datrez.setBounds(73, 143, 86, 20);
		frame.getContentPane().add(datrez);
		datrez.setColumns(10);
		
		JLabel nista = new JLabel("Ime rezervacije");
		nista.setFont(new Font("Yu Gothic", Font.BOLD, 12));
		nista.setBounds(71, 178, 107, 19);
		frame.getContentPane().add(nista);
		
		imerez = new JTextField();
		imerez.setBounds(73, 212, 140, 20);
		frame.getContentPane().add(imerez);
		imerez.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Br. osoba");
		lblNewLabel_4.setFont(new Font("Yu Gothic", Font.BOLD, 12));
		lblNewLabel_4.setBounds(280, 178, 72, 19);
		frame.getContentPane().add(lblNewLabel_4);
		
		brosoba = new JTextField();
		brosoba.setBounds(280, 212, 39, 20);
		frame.getContentPane().add(brosoba);
		brosoba.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Vrijeme dolaska");
		lblNewLabel_5.setFont(new Font("Yu Gothic", Font.BOLD, 12));
		lblNewLabel_5.setBounds(280, 108, 107, 22);
		frame.getContentPane().add(lblNewLabel_5);
		
		vrijeme = new JTextField();
		vrijeme.setBounds(280, 143, 86, 20);
		frame.getContentPane().add(vrijeme);
		vrijeme.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Konobar");
		lblNewLabel_3.setFont(new Font("Yu Gothic", Font.BOLD, 12));
		lblNewLabel_3.setBounds(697, 174, 71, 26);
		frame.getContentPane().add(lblNewLabel_3);
		
		
		JComboBox combo = new JComboBox();
		combo.setModel(new DefaultComboBoxModel(new String[] {"-ODABERI KONOBARA-", "Ema Sorić", "Katarina Grgur", "Zdenka Vlašić", "Zoran Šprajc"}));
		combo.setBounds(696, 211, 156, 22);
		frame.getContentPane().add(combo);
		
		
		JLabel lblNewLabel = new JLabel("REZERVACIJE STOLOVA");
		lblNewLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 20));
		lblNewLabel.setBounds(378, 24, 244, 58);
		frame.getContentPane().add(lblNewLabel);
		
		//JButton 
		JButton rezerviraj = new JButton("REZERVIRAJ");
		rezerviraj.setFont(new Font("Segoe UI", Font.BOLD, 14));
		rezerviraj.setBackground(new Color(111, 190, 217));
		rezerviraj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				imerezs=imerez.getText();
				datrezs=datrez.getText();
				vrijemes=vrijeme.getText();
				brosobas=brosoba.getText();
				brstolas=brstola.getText();
				
				konobar=combo.getSelectedItem().toString();//ono što je netko odabrao prebacujemo u string
				Object selected = combo.getSelectedItem();
				
				//uvijet za popunjavanje svih polja
				if (imerezs.equals("")||datrezs.equals("")||vrijemes.equals("")||brosobas.equals(""))
					JOptionPane.showMessageDialog(null, "Molimo popunite sva polja!");
				//uvijet za popunjavanje konobara u Jcomboboxu
				else if(selected.equals("-ODABERI KONOBARA-"))
				{
					JOptionPane.showMessageDialog(null, "Molimo odaberite konobara!");
				}
				//uvijet za popunjavanje samo brojeva u polje br stola
				else if(!brstolas.matches("[0-9]+"))//[]
                    JOptionPane.showMessageDialog(null,  "U polje stol moguće je unijeti samo brojeve!");
				//uvijet za popunjavanje samo brojeva u polje br osoba
				else if(!brosobas.matches("[0-9]+"))//[]
                    JOptionPane.showMessageDialog(null,  "U polje br osoba moguće je unijeti samo brojeve!");
				else
				{
					try
					{
						//postavljanje .txt datoteke za unos podataka
						String putanja ="C:\\Users\\Bojan\\Desktop\\Rezervacije.txt"; //povlači datoteku i njenu lokaciju ukoliko se ne nalazi u folderu od projekta
						FileWriter datoteka=new FileWriter(putanja, true);//true oznacava da se svaka nova promjena zapisuje na kraj prethodne
						String unos=datrezs+" - "+imerezs+" - "+vrijemes+" - "+brosobas+" - "+brstolas+" - "+konobar;
						datoteka.write(unos+"\n");
						datoteka.close();
						JOptionPane.showMessageDialog(null, "Rezervacija uspješno unesena!");
						
						//kod koji će nam vratiti praznu šablonu nakon unosa
						imerez.setText("");
						datrez.setText("");
						brstola.setText("");
						vrijeme.setText("");
						brosoba.setText("");
						
						
														
											
												
					}
					
					catch(IOException e1)
					{
						JOptionPane.showConfirmDialog(null, "Unos neuspiješan!");
					}
				}
			}
		});
		rezerviraj.setBounds(427, 262, 123, 26);
		frame.getContentPane().add(rezerviraj);
		
		JButton btnNewButton_2 = new JButton("POVRATAK");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Menu window = new Menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnNewButton_2.setFont(new Font("Segoe UI", Font.BOLD, 14));
		btnNewButton_2.setBounds(28, 24, 124, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("X");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_1.setBackground(new Color(255, 132, 132));
		btnNewButton_1.setBounds(939, 0, 45, 45);
		frame.getContentPane().add(btnNewButton_1);
		
		
		
		
		
		
		
		
	}
}
