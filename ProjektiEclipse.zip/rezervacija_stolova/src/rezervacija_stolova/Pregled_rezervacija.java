package rezervacija_stolova;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;


public class Pregled_rezervacija {

    public JFrame frame;
    private static JTable table;
    private JScrollPane tablica;
    private JScrollPane scrollPane;
    private JButton btnNewButton_1;
    private JButton btnNewButton_2;
    private JButton btnNewButton_3;
    private JButton btnBrisi;
    private JButton btnNewButton_4;
    private JTextField trazi;
    

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Pregled_rezervacija window = new Pregled_rezervacija();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public Pregled_rezervacija() {
        initialize(null, null, null, null, null, null);
    }

    /**
     * Initialize the contents of the frame.
     */
    public void initialize(String imerezs, String datrezs, String vrijemes, String brosobas, String brstolas, String konobar) {
        frame = new JFrame();
        frame.getContentPane().setBackground(new Color(215, 234, 234));
        frame.setBounds(100, 100, 1000, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setLayout(null);

        Object[] atributi = {"DATUM", "IME", "VRIJEME", "BROJ OSOBA", "BROJ STOLA", "KONOBAR"};
        DefaultTableModel model = new DefaultTableModel(atributi, 0);
        table = new JTable(model);

        scrollPane = new JScrollPane(table);
        scrollPane.setViewportBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
        scrollPane.setBounds(34, 148, 916, 239);
        frame.getContentPane().add(scrollPane);

        JLabel lblNewLabel = new JLabel("REZERVACIJE STOLOVA");
        lblNewLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 20));
        lblNewLabel.setBounds(378, 24, 244, 58);
        frame.getContentPane().add(lblNewLabel);

        JButton btnNewButton = new JButton("PRIKAŽI");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // kreiramo polje za unos podataka u tablicu
                try {
                	String podaci[] = {datrezs, imerezs, vrijemes, brosobas, brstolas, konobar};
                    DefaultTableModel tablicas = (DefaultTableModel) table.getModel();
                    tablicas.addRow(podaci);
                    
                    BufferedReader dat=new BufferedReader(new FileReader("C:\\Users\\Bojan\\Desktop\\Rezervacije.txt"));
                    String redak;
                    
                    
                    while((redak=dat.readLine())!=null)
				        {
                    	String[] pod = redak.split(" - ");
                        tablicas.addRow(pod);
                          
                        
                            
				        }
                    dat.close();
                    
                } catch (Exception e2) {
                    JOptionPane.showMessageDialog(null, "Greška!");
                }
            }
        });
       
        btnNewButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnNewButton.setBounds(846, 115, 104, 23);
        frame.getContentPane().add(btnNewButton);
        
        btnNewButton_1 = new JButton("POVRATAK");
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Menu window = new Menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
        	}
        });
        btnNewButton_1.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnNewButton_1.setBounds(34, 22, 124, 23);
        frame.getContentPane().add(btnNewButton_1);
        
        btnNewButton_2 = new JButton("X");
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		System.exit(0);
        	}
        });
        btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_2.setBackground(new Color(255, 132, 132));
        btnNewButton_2.setBounds(939, 0, 45, 45);
        frame.getContentPane().add(btnNewButton_2);
        
        btnNewButton_3 = new JButton("NOVA REZERVACIJA");
        btnNewButton_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Rezervacije window = new Rezervacije();
				window.frame.setVisible(true);
				frame.setVisible(false);
        	}
        });
        btnNewButton_3.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnNewButton_3.setBounds(417, 398, 180, 23);
        frame.getContentPane().add(btnNewButton_3);
        
        btnBrisi = new JButton("BRIŠI");
        btnBrisi.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		DefaultTableModel tablicas = (DefaultTableModel) table.getModel();
        		
        		//brisanje oznacenog retka
        		if(table.getSelectedRowCount()==1)
        		{
        			tablicas.removeRow(table.getSelectedRow());
        		}
        		else
        		{
        			if(table.getRowCount()==0)//ako nema redaka za brisanje
        				JOptionPane.showMessageDialog(null, "Tablica je prazna!");
        			else//ako ni jedan redak nije oznacen
        				JOptionPane.showMessageDialog(null, "Molimo označite redak!");
        		}
        	}
        });
        btnBrisi.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBrisi.setBounds(750, 387, 97, 23);
        frame.getContentPane().add(btnBrisi);
        
        trazi = new JTextField();
        trazi.setFont(new Font("Tahoma", Font.ITALIC, 11));
        trazi.setText("        Unesite traženi pojam");
        trazi.setBounds(34, 117, 383, 20);
        frame.getContentPane().add(trazi, BorderLayout.NORTH);
        trazi.setColumns(10);
        
        
        JButton btnAzuriraj = new JButton("AŽURIRAJ");
        btnAzuriraj.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        	}
        });
        
        btnAzuriraj.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAzuriraj.setBounds(846, 387, 104, 23);
        frame.getContentPane().add(btnAzuriraj);
        
        JButton btnTrazi = new JButton("TRAŽI");
        btnTrazi.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		        	
        		String 	trazis = trazi.getText();      		
        		DefaultTableModel tablicas = (DefaultTableModel) table.getModel();
                tablicas.setRowCount(0);
                
                try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Bojan\\Desktop\\Rezervacije.txt")))
                {                	
                	String redak;                	
                    while((redak=reader.readLine()) != null)
                    {
                    	String [] data=redak.split(" - ");
                    	
                    
                     	if (data[0].equals(trazis) || data[1].equals(trazis) || data[2].equals(trazis) || data[3].equals(trazis)||data[4].equals(trazis)||data[5].equals(trazis))
                	{
                     		tablicas.addRow(data);
                	}
                     	
                	}
                    if(tablicas.getRowCount()==0)
                    {
                    	JOptionPane.showMessageDialog(null, "Traženi pojam ne postoji.");
                	}                 	
                	else 
                	{    
                		JOptionPane.showMessageDialog(null, "Rezultati pretraživanja:");
                	}
                    reader.close();
                	}             
                catch (IOException e2) {
                    JOptionPane.showMessageDialog(null, "Greška pri čitanju datoteke.");
                } 
        	}   
        });	
        btnTrazi.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnTrazi.setBounds(417, 115, 180, 23);
        frame.getContentPane().add(btnTrazi, BorderLayout.SOUTH);
        
        
        
        
        
        
       
    }
}

