package projekt_rezervacije_stolova;
import projekt_rezervacije_stolova.Login;
import projekt_rezervacije_stolova.Registracija;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Reg_log {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reg_log window = new Reg_log();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Reg_log() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("REGISTRACIJA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Registracija registracija = new Registracija(); 
				registracija.showWindow();

				
			}
		});
		btnNewButton.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 14));
		btnNewButton.setBounds(139, 66, 155, 44);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login login = new Login();
				login.showWindow();
			}
		});
		btnLogin.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 14));
		btnLogin.setBounds(139, 143, 155, 44);
		frame.getContentPane().add(btnLogin);
	}

	public void showWindow() {
		frame.setVisible(true);
	}
	
}
