package projekt_rezervacije_stolova;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;//

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;//
import java.sql.DriverManager;//
import java.sql.PreparedStatement;
import java.sql.ResultSet; //

public class Registracija {

	private JFrame frame;
	private JTextField gost_ime;
	private JTextField gost_prezime;
	private JTextField korisnicko_ime;
	private JPasswordField lozinka;
	private JPasswordField lozinka1;
	private JTextField br_mobitela;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registracija window = new Registracija();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Registracija() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Rockwell", Font.BOLD, 14));
		frame.getContentPane().setBackground(new Color(230, 230, 250));
		frame.setBounds(100, 100, 585, 524);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("REGISTRACIJA");
		lblNewLabel.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		lblNewLabel.setBackground(new Color(230, 230, 250));
		lblNewLabel.setBounds(193, 22, 182, 27);
		frame.getContentPane().add(lblNewLabel);
		
		gost_ime = new JTextField();
		gost_ime.setBounds(190, 113, 200, 20);
		frame.getContentPane().add(gost_ime);
		gost_ime.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Ime:");
		lblNewLabel_1.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(269, 88, 36, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Prezime:");
		lblNewLabel_2.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(256, 144, 63, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		gost_prezime = new JTextField();
		gost_prezime.setBounds(187, 169, 200, 20);
		frame.getContentPane().add(gost_prezime);
		gost_prezime.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("korisnicko ime \r\n(e-mail):");
		lblNewLabel_3.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(210, 200, 155, 20);
		frame.getContentPane().add(lblNewLabel_3);
		
		korisnicko_ime = new JTextField();
		korisnicko_ime.setBounds(187, 229, 200, 20);
		frame.getContentPane().add(korisnicko_ime);
		korisnicko_ime.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Lozinka:");
		lblNewLabel_4.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(261, 253, 52, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("Ponovljena lozinka:");
		lblNewLabel_4_1.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_4_1.setBounds(222, 305, 130, 14);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		lozinka = new JPasswordField();
		lozinka.setBounds(187, 278, 200, 20);
		frame.getContentPane().add(lozinka);
		
		lozinka1 = new JPasswordField();
		lozinka1.setBounds(187, 330, 200, 20);
		frame.getContentPane().add(lozinka1);
		
		JLabel lblNewLabel_5 = new JLabel("Broj mobitela:");
		lblNewLabel_5.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(239, 365, 97, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		br_mobitela = new JTextField();
		br_mobitela.setBounds(187, 390, 200, 20);
		frame.getContentPane().add(br_mobitela);
		br_mobitela.setColumns(10);
		
		JButton btnNewButton = new JButton("REGISTRIRAJ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String gost_imes =gost_ime.getText();
				String gost_prezimes=gost_prezime.getText();
				String korisnicko_imes=korisnicko_ime.getText();
				String lozinkas=new String (lozinka.getPassword());
				String lozinkas1=new String (lozinka1.getPassword());
				String br_mobitelas=br_mobitela.getText();
				
				
				//podudaranje lozinki
				if (lozinkas.equals(lozinkas1)) 
				{
					try {
						//povezivanje na server
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

						//sql upit
						String provjera= "SELECT * FROM gost WHERE korisnicko_ime=?";
						
						PreparedStatement ps= con.prepareStatement(provjera);
						ps.setString(1, korisnicko_imes);
						
						//spremanje rezultata
						ResultSet rs=ps.executeQuery();
						
						if(rs.next())
						{
							JOptionPane.showMessageDialog(null, "Korisnik sa tim korisničkim imenom već postoji. Molimo pokušajte ponovo.");
						}
						else {
							//postavljamo sql upit
							String upit="INSERT INTO gost(korisnicko_ime, gost_ime, gost_prezime, br_mobitela, lozinka) VALUES (?,?,?,?,?)";
							PreparedStatement regPs=con.prepareStatement(upit);
							regPs.setString(1, korisnicko_imes);
							regPs.setString(2, gost_imes);
							regPs.setString(3, gost_prezimes);
							regPs.setString(4, br_mobitelas);
							regPs.setString(5, lozinkas);
							
							int ubaceno_redaka=regPs.executeUpdate();
							
							if(ubaceno_redaka==1)
							{
								JOptionPane.showMessageDialog(null, "Registracija uspješna.");
							}
							else
							{
								JOptionPane.showMessageDialog(null, "Registracija neuspješna. Pokušajte ponovo.");
							}
						}
							
						} 
					
									
				
				
			catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Server ne reagira. (e1)");
				}
				
				
			
				
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Lozinke se ne podudaraju.");
				}

			
	}

		
		});
		btnNewButton.setFont(new Font("Rockwell", Font.BOLD, 14));
		btnNewButton.setBounds(216, 431, 136, 27);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("<--");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reg_log reg_log = new Reg_log(); 
				reg_log.showWindow();
				
				
			}
			
		});
		btnNewButton_1.setFont(new Font("Rockwell Extra Bold", Font.PLAIN, 12));
		btnNewButton_1.setBounds(0, 0, 52, 23);
		frame.getContentPane().add(btnNewButton_1);

}
	public void showWindow() {
		frame.setVisible(true);
	}
	}
