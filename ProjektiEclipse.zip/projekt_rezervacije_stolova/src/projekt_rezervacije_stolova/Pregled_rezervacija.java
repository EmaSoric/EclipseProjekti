package projekt_rezervacije_stolova;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;

public class Pregled_rezervacija {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pregled_rezervacija window = new Pregled_rezervacija();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Pregled_rezervacija() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 689, 537);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Pregled rezervacija");
		lblNewLabel.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		lblNewLabel.setBounds(209, 11, 254, 67);
		frame.getContentPane().add(lblNewLabel);
	}
	public void showWindow() {
		frame.setVisible(true);
	}
}
