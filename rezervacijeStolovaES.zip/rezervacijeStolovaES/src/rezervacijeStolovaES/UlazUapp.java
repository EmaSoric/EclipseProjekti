package rezervacijeStolovaES;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UlazUapp {

	public JFrame frame;
	JButton btn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UlazUapp window = new UlazUapp();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UlazUapp() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 492, 476);
		frame.getContentPane().setBackground(new Color(140, 190, 215));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("REZERVACIJE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				GlavniMenu window = new GlavniMenu();
				window.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog
				
			}
		});
		btnNewButton.setBounds(131, 127, 200, 51);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnKonobari = new JButton("KONOBARI");
		btnKonobari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				KonobariMenu konobariMenu = new KonobariMenu();
				konobariMenu.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog
				
			}
		});
		btnKonobari.setBounds(131, 198, 200, 51);
		frame.getContentPane().add(btnKonobari);
		
		JButton btnStolovi = new JButton("STOLOVI");
		btnStolovi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Stolovi window = new Stolovi();
				window.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog
				
			}
		});
		btnStolovi.setBounds(131, 271, 200, 51);
		frame.getContentPane().add(btnStolovi);
		
		ImageIcon slika= new ImageIcon("C:\\Users\\Ema\\Downloads\\homeIcon.png");
		Image originalImage = slika.getImage();
		btn = new JButton();
		
		int newWidth = 30;
        int newHeight = 25;
        
        Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
		//btn.setText("Bok");
		btn.setFocusable(false);
		btn.setIcon(resizedIcon);
		
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reg_log window = new Reg_log();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		btn.setBounds(10, 11, 89, 23);
		frame.getContentPane().add(btn);
	}

}
