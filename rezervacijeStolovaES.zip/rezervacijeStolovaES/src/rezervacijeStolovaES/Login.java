package rezervacijeStolovaES;
import org.mindrot.jbcrypt.BCrypt;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Login {

	public JFrame frame;
	private JTextField korisnicko_ime;
	private JPasswordField lozinka;
	JButton btn;
				

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {			
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(140, 190, 215));
		frame.setBounds(100, 100, 492, 476);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOGIN");
		lblNewLabel.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		lblNewLabel.setBounds(197, 32, 82, 24);
		frame.getContentPane().add(lblNewLabel);
		
		korisnicko_ime = new JTextField();
		korisnicko_ime.setBounds(138, 173, 200, 20);
		frame.getContentPane().add(korisnicko_ime);
		korisnicko_ime.setColumns(10);
		
		lozinka = new JPasswordField();
		lozinka.setBounds(138, 242, 200, 20);
		frame.getContentPane().add(lozinka);
		lozinka.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Korisnicko ime:");
		lblNewLabel_1.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(184, 148, 107, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Lozinka:");
		lblNewLabel_2.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(212, 217, 52, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("LOGIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String korisnicko_imes=korisnicko_ime.getText();
				char[] lozinkach=lozinka.getPassword();				
				String lozinkas=new String (lozinkach);
				
				try {
					//treba nam JDBC koji smo skinuli sa, svaki projekt koji se spaja na bazu ga mora imati
					//Konekcija na bazu:
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");
				
					String provjera="SELECT * FROM konobar WHERE korisnicko_ime=?";
					PreparedStatement ps=con.prepareStatement(provjera); 
					ps.setString(1, korisnicko_imes);
					
					
					ResultSet rs=ps.executeQuery();
					
					if (rs.next()) {
                        String hashLozinkeBaza = rs.getString("lozinka");
                       
                        if (BCrypt.checkpw(lozinkas, hashLozinkeBaza)) {
                            UlazUapp window = new UlazUapp();
    						window.frame.setVisible(true);
    						frame.setVisible(false);

                        } 
                        else 
                        {
                            JOptionPane.showMessageDialog(null, "Pogrešna lozinka");
                        }
                    } 
					else 
					{
                        JOptionPane.showMessageDialog(null, "Korisnik s tim korisničkim imenom ne postoji");
                    }
					
					
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Greška prilikom spajanja na server. (e1)");
					System.out.println(e1);
				}
			}
		});
		btnNewButton.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 14));
		btnNewButton.setBounds(189, 336, 98, 33);
		frame.getContentPane().add(btnNewButton);
		
		ImageIcon slika= new ImageIcon("C:\\Users\\Ema\\Downloads\\nazad.png");
		Image originalImage = slika.getImage();
		btn = new JButton();
		
		int newWidth = 30;
        int newHeight = 25;
        
        Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
		//btn.setText("Bok");
		btn.setFocusable(false);
		btn.setIcon(resizedIcon);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reg_log window = new Reg_log();
				window.frame.setVisible(true);
				frame.setVisible(false);
				
			}
		});
		btn.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(btn);
		
		
		
		
		
		
	}

	public void showWindow() {
		frame.setVisible(true);
	}
}
