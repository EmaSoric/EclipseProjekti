package rezervacijeStolovaES;
import org.mindrot.jbcrypt.BCrypt;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;//

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;



import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;//

public class Registracija {

	public JFrame frame;
	private JTextField ime;
	private JTextField prezime;
	private JTextField korisnicko_ime;
	private JPasswordField lozinka;
	private JPasswordField lozinka1;
	private JTextField br_mob;
	JButton btn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registracija window = new Registracija();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Registracija() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Rockwell", Font.BOLD, 14));
		frame.getContentPane().setBackground(new Color(140, 190, 215));
		frame.setBounds(100, 100, 585, 524);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("REGISTRACIJA");
		lblNewLabel.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		lblNewLabel.setBackground(new Color(230, 230, 250));
		lblNewLabel.setBounds(193, 22, 182, 27);
		frame.getContentPane().add(lblNewLabel);
		
		ime = new JTextField();
		ime.setBounds(190, 113, 200, 20);
		frame.getContentPane().add(ime);
		ime.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Ime:");
		lblNewLabel_1.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(269, 88, 36, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Prezime:");
		lblNewLabel_2.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(256, 144, 63, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		prezime = new JTextField();
		prezime.setBounds(187, 169, 200, 20);
		frame.getContentPane().add(prezime);
		prezime.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Korisnicko ime:");
		lblNewLabel_3.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(210, 200, 155, 20);
		frame.getContentPane().add(lblNewLabel_3);
		
		korisnicko_ime = new JTextField();
		korisnicko_ime.setBounds(187, 229, 200, 20);
		frame.getContentPane().add(korisnicko_ime);
		korisnicko_ime.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Lozinka:");
		lblNewLabel_4.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(261, 253, 52, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("Ponovljena lozinka:");
		lblNewLabel_4_1.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_4_1.setBounds(222, 305, 130, 14);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		lozinka = new JPasswordField();
		lozinka.setBounds(187, 278, 200, 20);
		frame.getContentPane().add(lozinka);
		
		lozinka1 = new JPasswordField();
		lozinka1.setBounds(187, 330, 200, 20);
		frame.getContentPane().add(lozinka1);
		
		JLabel lblNewLabel_5 = new JLabel("Broj mobitela:");
		lblNewLabel_5.setFont(new Font("Rockwell", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(239, 365, 97, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		br_mob = new JTextField();
		br_mob.setBounds(187, 390, 200, 20);
		frame.getContentPane().add(br_mob);
		br_mob.setColumns(10);
		
		JButton btnNewButton = new JButton("REGISTRIRAJ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String imes =ime.getText();
				String prezimes=prezime.getText();
				String korisnicko_imes=korisnicko_ime.getText();
				char[] lozinkach=lozinka.getPassword();
				char[] lozinka1ch=lozinka1.getPassword();
				
				String lozinkas=new String (lozinkach);
				String lozinkas1=new String (lozinka1ch);
				
				String br_mobs=br_mob.getText();
				
				
				//Generirajte sol za bcrypt
                String salt = BCrypt.gensalt();
                System.out.println("Generirana sol: " + salt);
                
               //  Hashirajte lozinku sa soli
                String hashLozinke = BCrypt.hashpw(lozinkas, salt);
                System.out.println("Generirani hash: " + hashLozinke);

				
				//podudaranje lozinki
				if (lozinkas.equals(lozinkas1)) 
				{
					try {
						//povezivanje na server
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC","esoric", "11");


						//sql upit
						String provjera= "SELECT * FROM konobar WHERE korisnicko_ime=?";
						
						PreparedStatement ps= con.prepareStatement(provjera);
						ps.setString(1, korisnicko_imes);
						
						//spremanje rezultata
						ResultSet rs=ps.executeQuery();
						
						if(rs.next())
						{
							JOptionPane.showMessageDialog(null, "Korisnik sa tim korisničkim imenom već postoji. Molimo pokušajte ponovo.");
						}
						else {
							
							
			                
							//postavljamo sql upit
							String upit="INSERT INTO konobar (ime, prezime, korisnicko_ime, lozinka, br_mob) VALUES (?,?,?,?,?)";
							PreparedStatement regPs=con.prepareStatement(upit);
							
							regPs.setString(1, imes);
							regPs.setString(2, prezimes);
							regPs.setString(3, korisnicko_imes);
							regPs.setString(4, hashLozinke);
							regPs.setString(5, br_mobs);
							
							int ubaceno_redaka=regPs.executeUpdate();
							
							ime.setText("");
							prezime.setText("");
							korisnicko_ime.setText("");
							lozinka.setText("");
							lozinka1.setText("");
							br_mob.setText("");
							
							if(ubaceno_redaka==1)
							{
								JOptionPane.showMessageDialog(null, "Registracija uspješna.");
								
								Reg_log window = new Reg_log();
								window.frame.setVisible(true);
								frame.setVisible(false);
							}
							else
							{
								JOptionPane.showMessageDialog(null, "Registracija neuspješna. Pokušajte ponovo.");
							}
						}
							
						} 
					
									
				
				
			catch(Exception e1)
				{
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "Greška prilikom spajanja na server");
					System.out.println(e1);
				}
							
				
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Lozinke se ne podudaraju.");
				}

			
	}

		
		});
		btnNewButton.setFont(new Font("Rockwell", Font.BOLD, 14));
		btnNewButton.setBounds(216, 431, 136, 27);
		frame.getContentPane().add(btnNewButton);
		
		ImageIcon slika= new ImageIcon("C:\\Users\\Ema\\Downloads\\nazad.png");
		Image originalImage = slika.getImage();
		btn = new JButton();
		
		int newWidth = 30;
        int newHeight = 25;
        
        Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
		//btn.setText("Bok");
		btn.setFocusable(false);
		btn.setIcon(resizedIcon);
		
		
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reg_log window = new Reg_log();
				window.frame.setVisible(true);
				frame.setVisible(false);
				
				
			}
			
		});
		btn.setFont(new Font("Rockwell Extra Bold", Font.PLAIN, 12));
		btn.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(btn);
		
		

}
	public void showWindow() {
		frame.setVisible(true);
	}
	}
