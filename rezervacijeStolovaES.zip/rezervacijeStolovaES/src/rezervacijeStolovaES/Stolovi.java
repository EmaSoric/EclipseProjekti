package rezervacijeStolovaES;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Stolovi {

	public JFrame frame;
	private JTextField trazi;
	private JTable tablica;
	private JTextField stol;
	private JTextField mjesto;
	JButton btn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Stolovi window = new Stolovi();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Stolovi() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(140, 190, 215));///   100, 149, 237
		frame.setBounds(100, 100, 1118, 577);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Pregled stolova:");
		lblNewLabel_1.setFont(new Font("Corbel", Font.BOLD, 16));
		lblNewLabel_1.setBounds(121, 65, 227, 38);
		frame.getContentPane().add(lblNewLabel_1);
		
		trazi = new JTextField();
		trazi.setBounds(624, 120, 191, 27);
		frame.getContentPane().add(trazi);
		trazi.setColumns(10);
		
		JButton btnNewButton = new JButton("Traži");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
String trazis=trazi.getText();
				
				
				try
				{
					
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					String upit="SELECT * FROM stol k WHERE broj_stola LIKE ? OR broj_mjesta LIKE ?"; 
					
					PreparedStatement ps=con.prepareStatement(upit);
					ps.setString(1, "%" +trazis+ "%");
					ps.setString(2, "%" +trazis+ "%");
				
					
					ResultSet rs=ps.executeQuery();
					
					DefaultTableModel model=(DefaultTableModel)tablica.getModel();
					
					model.setRowCount(0);
					
					while(rs.next())
					{
						int stol=rs.getInt(1);
						int mjesto=rs.getInt(2);
						
						model.addRow(new Object[] {stol, mjesto});
						
						
					}
					trazi.setText("");
					
				}
				catch (Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Serverska greška." +e1);
				}
				
			}
		});
		btnNewButton.setBounds(825, 120, 80, 27);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Briši");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel model=(DefaultTableModel)tablica.getModel();
				
				int odabraniRedak=tablica.getSelectedRow();
				
				if(odabraniRedak>=0)
				{
					try
					{
						String br_stola=(String)tablica.getValueAt(odabraniRedak, 0);
						String br_mjesta=(String)tablica.getValueAt(odabraniRedak, 1);
						
						//nakon što smo označili redak i njegove vrijednosti
						//sada brisemo iz baze
						
						Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
						Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

						String upit="DELETE FROM stol WHERE broj_stola=? AND broj_mjesta=?";
						PreparedStatement ps=con.prepareStatement(upit);
						ps.setString(1, br_stola);
						ps.setString(2, br_mjesta);
						
						int rezultat=ps.executeUpdate();
						
						if(rezultat==1)
						{
							DefaultTableModel model1=(DefaultTableModel)tablica.getModel();
							model1.removeRow(odabraniRedak);
							JOptionPane.showMessageDialog(null, "Stol je uspješno izbrisan.");
							
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Stol nije moguće izbrisati.");
						}
						
					}
					catch(Exception e1)
					{
						JOptionPane.showMessageDialog(null, "Serverska greška." +e1);
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Odaberite redak.");
				}
				
			}
		});
		btnNewButton_2.setBounds(634, 180, 89, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(49, 121, 541, 335);
		frame.getContentPane().add(scrollPane);
		
		tablica = new JTable();
		tablica.addMouseListener(new MouseAdapter() {
			
			public void mouseClicked(MouseEvent e) {
				int odabraniRedak=tablica.getSelectedRow();
				
				mjesto.setText(tablica.getValueAt(odabraniRedak,1).toString());
				stol.setText(tablica.getValueAt(odabraniRedak, 0).toString());
			}
		});
		scrollPane.setViewportView(tablica);
		tablica.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Broj stola", "Broj sjede\u0107ih mjesta"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		JButton btnNewButton_3 = new JButton("Dodaj");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DodajStol window = new DodajStol();
				window.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog

			}
		});
		btnNewButton_3.setBounds(634, 231, 89, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		ImageIcon slika= new ImageIcon("C:\\Users\\Ema\\Downloads\\nazad.png");
		Image originalImage = slika.getImage();
		btn = new JButton();
		
		int newWidth = 30;
        int newHeight = 25;
        
        Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
		//btn.setText("Bok");
		btn.setFocusable(false);
		btn.setIcon(resizedIcon);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UlazUapp window = new UlazUapp();
				window.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog
				
			}
		});
		btn.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(btn);
				

		
		JButton btnNewButton_3_1 = new JButton("PREGLED STOLOVA");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					String upit="SELECT * FROM stol";
					Statement stmt=con.createStatement(); //con zna di se nalazi upit a statement priprema upit
					ResultSet rs=stmt.executeQuery(upit);
					
					DefaultTableModel model=(DefaultTableModel)tablica.getModel();
					model.setRowCount(0);
					
					while(rs.next())
					{
						String br_stola=rs.getString(1);
						String br_mjesta=rs.getString(2);
						
						model.addRow(new Object[] {br_stola, br_mjesta});
					}
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Serverska greška." +e1);
				}
			}
		});
		btnNewButton_3_1.setBounds(440, 98, 150, 23);
		frame.getContentPane().add(btnNewButton_3_1);
		
		JLabel lblNewLabel = new JLabel("Izmijeni podatke o stolovima:");
		lblNewLabel.setBounds(635, 295, 200, 14);
		frame.getContentPane().add(lblNewLabel);
		
		stol = new JTextField();
		stol.setBounds(637, 350, 40, 40);
		frame.getContentPane().add(stol);
		stol.setColumns(10);
		
		mjesto = new JTextField();
		mjesto.setColumns(10);
		mjesto.setBounds(733, 350, 40, 40);
		frame.getContentPane().add(mjesto);
		
		JLabel lblNewLabel_2 = new JLabel("Broj stola:");
		lblNewLabel_2.setBounds(624, 325, 70, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Broj sjedećih mjesta:");
		lblNewLabel_2_1.setBounds(720, 325, 150, 14);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JButton btnNewButton_1 = new JButton("Izmijeni");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int stols=Integer.parseInt(stol.getText());
				int mjestos=Integer.parseInt(mjesto.getText());
				
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					String upit="UPDATE stol SET broj_mjesta=? WHERE broj_stola=?";
					
					PreparedStatement ps=con.prepareStatement(upit);
					
					ps.setInt(2, stols);
					ps.setInt(1, mjestos);
					
					
					int updateRedak=ps.executeUpdate();
					stol.setText("");
					mjesto.setText("");
					if(updateRedak > 0)
					{
						
						JOptionPane.showMessageDialog(null, "Promjena broja sjedećih mjesta za stol: " +stols+" je uspiješno spremljena.");
						
					}
					else 
					{
		                JOptionPane.showMessageDialog(null, "Pokušaj izmjene nije uspio.");
		            }
					String upit2="SELECT * FROM stol";
					Statement stmt=con.createStatement(); //con zna di se nalazi upit a statement priprema upit
					ResultSet rs=stmt.executeQuery(upit2);
					
					DefaultTableModel model=(DefaultTableModel)tablica.getModel();
					model.setRowCount(0);
					
					while(rs.next())
					{
						String br_stola=rs.getString(1);
						String br_mjesta=rs.getString(2);
						
						model.addRow(new Object[] {br_stola, br_mjesta});
					}
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Serverska greška." +e1);
				}
			}
		});
		btnNewButton_1.setBounds(634, 412, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		tablica.getColumnModel().getColumn(1).setPreferredWidth(112);
	}
}
