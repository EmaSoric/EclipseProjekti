package rezervacijeStolovaES;

import rezervacijeStolovaES.KonobariMenu;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JToolBar;
import java.awt.BorderLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.SystemColor;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;

public class GlavniMenu {

	public JFrame frame; //prozor smo morali staviti na public kako bi nam ostatak aplikacije moga upravljati prozorima
	private JTable table;
	private JTextField datum;
	private JTextField brOsoba;
	private JTextField vrijeme;
	private JTextField naziv;
	private JTable tablica;
	private JTextField napomena;
	private JTextField trazi;
	private int broj_rezervacije;
	JButton btn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GlavniMenu window = new GlavniMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GlavniMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1118, 577);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				datum.setText("");
				vrijeme.setText("");
				naziv.setText("");
				datum.setText("");
				brOsoba.setText("");
				napomena.setText("");
				
			
			}
		});
		panel.setBackground(new Color(140, 190, 215));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("KONOBARI");
		btnNewButton.setFont(new Font("Corbel", Font.BOLD, 18));
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				KonobariMenu konobariMenu = new KonobariMenu();
				konobariMenu.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog

				
					
			}
			
		});
		btnNewButton.setBounds(597, 0, 505, 45);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("REZERVACIJE");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Corbel", Font.BOLD, 18));
		lblNewLabel.setBackground(SystemColor.activeCaption);
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(0, 0, 587, 45);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Unos rezervacije:");
		lblNewLabel_1.setFont(new Font("Corbel", Font.BOLD, 16));
		lblNewLabel_1.setBounds(22, 56, 227, 38);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Pregled rezervacije:");
		lblNewLabel_2.setFont(new Font("Corbel", Font.BOLD, 16));
		lblNewLabel_2.setBounds(26, 238, 139, 30);
		panel.add(lblNewLabel_2);
		
		datum = new JTextField();
		datum.setBounds(22, 146, 107, 30);
		panel.add(datum);
		datum.setColumns(10);
		
		brOsoba = new JTextField();
		brOsoba.setBounds(478, 146, 127, 30);
		panel.add(brOsoba);
		brOsoba.setColumns(10);
		
		vrijeme = new JTextField();
		vrijeme.setColumns(10);
		vrijeme.setBounds(139, 146, 86, 30);
		panel.add(vrijeme);
		
		naziv = new JTextField();
		naziv.setColumns(10);
		naziv.setBounds(235, 146, 233, 30);
		panel.add(naziv);
		
		JLabel lblNewLabel_3 = new JLabel("Datum:");
		lblNewLabel_3.setBounds(22, 122, 46, 14);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Vrijeme:");
		lblNewLabel_3_1.setBounds(138, 122, 77, 14);
		panel.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3_2 = new JLabel("Naziv rezervacije:");
		lblNewLabel_3_2.setBounds(235, 122, 115, 14);
		panel.add(lblNewLabel_3_2);
		
		JLabel lblNewLabel_3_3 = new JLabel("Broj osoba:");
		lblNewLabel_3_3.setBounds(478, 121, 77, 14);
		panel.add(lblNewLabel_3_3);
		
		JLabel lblNewLabel_3_4 = new JLabel("Stol:");
		lblNewLabel_3_4.setBounds(625, 121, 46, 14);
		panel.add(lblNewLabel_3_4);
		
		JLabel lblNewLabel_3_5 = new JLabel("Konobar:");
		lblNewLabel_3_5.setBounds(776, 121, 46, 14);
		panel.add(lblNewLabel_3_5);
		
		napomena = new JTextField();
		napomena.setColumns(10);
		napomena.setBounds(911, 146, 140, 100);
		panel.add(napomena);
		
		JComboBox comboKonobar = new JComboBox();
		comboKonobar.setBounds(762, 146, 139, 30);
		panel.add(comboKonobar);
		{
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
				Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

				//prvo moramo popuniti kombo da bi mogli povući odabir za spremanje u bazu
				String upit="SELECT korisnicko_ime FROM konobar";
				
				Statement stmt=con.createStatement(); //poveznica prema bazi koja javlja da će joj se poslati upit
				ResultSet rs=stmt.executeQuery(upit);
				
				while(rs.next())
				{
					String podatak=rs.getString(1);
					comboKonobar.addItem(podatak);
				}
			}
			catch(Exception e1)
			{
				JOptionPane.showMessageDialog(null, "Greška na serveru." +e1);
			}
		}
		
		JComboBox comboStol = new JComboBox();
		comboStol.setBounds(615, 146, 130, 30);
		panel.add(comboStol);
		{
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
				Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

				//prvo moramo popuniti kombo da bi mogli povući odabir za spremanje u bazu
				String upit="SELECT broj_stola FROM stol";
				
				Statement stmt=con.createStatement(); //poveznica prema bazi koja javlja da će joj se poslati upit
				ResultSet rs=stmt.executeQuery(upit);
				
				while(rs.next())
				{
					String podatak1=rs.getString(1);
					comboStol.addItem(podatak1);
				}
			}
			catch(Exception e1)
			{
				JOptionPane.showMessageDialog(null, "Greška na serveru." +e1);
			}
		}
		
		JButton btnNewButton_1 = new JButton("Spremi");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String datums=datum.getText();
				String vrijemes=vrijeme.getText();
				String nazivs=naziv.getText();
				String brOsobas=brOsoba.getText();
				
				String odabraniKonobar=(String)comboKonobar.getSelectedItem();//objekt pretvaramo u string
				String odabraniStol=(String)comboStol.getSelectedItem();//isto kao toString funkcija
				
				String napomenas=napomena.getText();
				if (datums.equals("")||vrijemes.equals("")||nazivs.equals("")||brOsobas.equals(""))
					JOptionPane.showMessageDialog(null, "Molimo popunite sva polja!");
				else if (!brOsobas.matches("[0-9]+"))//[]
                JOptionPane.showMessageDialog(null,  "U polje Broj osoba moguće je unijeti samo brojeve!");
				else {
				try
				{
					int osobabr=Integer.parseInt(brOsobas);
					
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					String upitKonobar = "SELECT sifra_konobara FROM konobar WHERE korisnicko_ime='"+odabraniKonobar+"'";//odabrani konobar mora biti unutar navodnika u sql upitu zato smo stavili
					//jednostruke navodnike prijekraja prvog dijela upita i na kraju zatvorili jednostruki navodnik unutar dvostrukih
					
					String upitStol = "SELECT broj_stola FROM stol WHERE broj_stola='"+odabraniStol+"'";
					
					Statement stmt1=con.createStatement();//poveznica prema bazi koja najavljuje da ce se poslati upit
					Statement stmt2=con.createStatement();
					ResultSet rs1=stmt1.executeQuery(upitKonobar);
					ResultSet rs2=stmt2.executeQuery(upitStol);
					
					int konobarc=0;
					int stolc=0;
					
					if(rs1.next())//u retku trazimo selektirani clan
					{
						konobarc=rs1.getInt(1);
					}
					if(rs2.next())
					{
						stolc=rs2.getInt(1);
					}
					
					String dodajRezervaciju="INSERT INTO rezervacija (datum, vrijeme, naziv_rezervacije, br_osoba, broj_stola, sifra_konobara, posebne_napomene) VALUES(?,?,?,?,?,?,?)";
					PreparedStatement psRezervacija=con.prepareStatement(dodajRezervaciju);
					psRezervacija.setString(1, datums);
					psRezervacija.setString(2, vrijemes);
					psRezervacija.setString(3, nazivs);
					psRezervacija.setInt(4,osobabr);
					psRezervacija.setInt(5,stolc);
					psRezervacija.setInt(6, konobarc);
					psRezervacija.setString(7, napomenas);
					
					int ubacenoRedaka=psRezervacija.executeUpdate();
					
					datum.setText("");
					vrijeme.setText("");
					naziv.setText("");
					datum.setText("");
					brOsoba.setText("");
					napomena.setText("");
					
					
					if(ubacenoRedaka==1)
					{
						JOptionPane.showMessageDialog(null, "Rezervacija je spremljena.");
						
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Rezervacija nije unesena. Molimo pokušajte ponovo.");
					}
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Serverska greška. "+e1);
				}
				}

				
			}
		});
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.setBounds(398, 188, 305, 30);
		panel.add(btnNewButton_1);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(22, 279, 900, 248);
		panel.add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		
		tablica = new JTable();
		tablica.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//kada kliknemo na tablicu da nam odabrani redak prebaci u polja za izmjenu rezervacije
				int odabraniRedak=tablica.getSelectedRow();
				datum.setText(tablica.getValueAt(odabraniRedak, 1).toString());
				vrijeme.setText(tablica.getValueAt(odabraniRedak, 2).toString());
				naziv.setText(tablica.getValueAt(odabraniRedak, 3).toString());
				brOsoba.setText(tablica.getValueAt(odabraniRedak, 4).toString());
				comboStol.setSelectedItem(tablica.getValueAt(odabraniRedak, 5));
				comboKonobar.setSelectedItem(tablica.getValueAt(odabraniRedak, 6)); 
				 
				
				napomena.setText(tablica.getValueAt(odabraniRedak, 7).toString());
				broj_rezervacije=Integer.parseInt(tablica.getValueAt(odabraniRedak, 0).toString());
			}
		});
		scrollPane.setViewportView(tablica);
		tablica.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Br. rez.", "Datum:", "Vrijeme:", "Naziv rezervacije:", "Broj osoba:", "Stol:", "Konobar:", "Posebne napomene"
			}
		));
		tablica.getColumnModel().getColumn(0).setPreferredWidth(30);
		tablica.getColumnModel().getColumn(1).setPreferredWidth(50);
		tablica.getColumnModel().getColumn(2).setPreferredWidth(50);
		tablica.getColumnModel().getColumn(3).setPreferredWidth(200);
		tablica.getColumnModel().getColumn(3).setMinWidth(200);
		tablica.getColumnModel().getColumn(4).setPreferredWidth(50);
		tablica.getColumnModel().getColumn(5).setPreferredWidth(60);
		tablica.getColumnModel().getColumn(7).setPreferredWidth(130);
		
		JLabel lblNewLabel_3_5_1 = new JLabel("Dodatne napomene:");
		lblNewLabel_3_5_1.setBounds(924, 122, 100, 14);
		panel.add(lblNewLabel_3_5_1);
		
		
		
		trazi = new JTextField();
		trazi.setBounds(250, 241, 300, 20);
		panel.add(trazi);
		trazi.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Traži");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String trazis=trazi.getText();
				
				
				try
				{
					
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					//String upit="SELECT k.sifra_konobara, k.ime, k.prezime, k.korisnicko_ime, k.br_mob FROM konobar k WHERE sifra_konobara LIKE ? OR ime LIKE ? OR prezime LIKE ? OR korisnicko_ime LIKE ? OR br_mob LIKE ?"; 
					
					String upit = "SELECT r.broj_rezervacije, r.datum, r.vrijeme, r.naziv_rezervacije, r.br_osoba, r.broj_stola, k.korisnicko_ime, r.posebne_napomene "
						    + "FROM rezervacija r JOIN konobar k ON r.sifra_konobara = k.sifra_konobara "
						    + "WHERE broj_rezervacije LIKE ? OR datum LIKE ? OR vrijeme LIKE ? OR naziv_rezervacije LIKE ? OR br_osoba LIKE ? OR broj_stola LIKE ? OR korisnicko_ime LIKE ? OR posebne_napomene LIKE ?";
					
					PreparedStatement ps=con.prepareStatement(upit);
					ps.setString(1, "%"+trazis+"%");
					ps.setString(2, "%"+trazis+"%");
					ps.setString(3, "%"+trazis+"%");
					ps.setString(4, "%" +trazis+ "%");
					ps.setString(5, "%" +trazis+ "%");
					ps.setString(6, "%" +trazis+ "%");
					ps.setString(7, "%" +trazis+ "%");
					ps.setString(8, "%" +trazis+ "%");
					
					ResultSet rs=ps.executeQuery();
					
					DefaultTableModel model=(DefaultTableModel)tablica.getModel();
					
					model.setRowCount(0);
					
					while(rs.next())
					{
						int broj_rezervacije=rs.getInt(1);
						String datum=rs.getString(2);
						String vrijeme=rs.getString(3);
						String naziv=rs.getString(4);
						String br_osoba=rs.getString(5);
						String br_stola=rs.getString(6);
						String konobar=rs.getString(7);
						String napomene=rs.getString(8);
						
						model.addRow(new Object[] {broj_rezervacije, datum, vrijeme, naziv, br_osoba, br_stola , konobar, napomene});
						
						
					}
					
					
				}
				catch (Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Serverska greška." +e1);
				}
			}
		});
		btnNewButton_2.setBounds(560, 240, 89, 23);
		panel.add(btnNewButton_2);
		
		ImageIcon slika= new ImageIcon("C:\\Users\\Ema\\Downloads\\nazad.png");
		Image originalImage = slika.getImage();
		btn = new JButton();
		
		int newWidth = 30;
        int newHeight = 25;
        
        Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
		//btn.setText("Bok");
		btn.setFocusable(false);
		btn.setIcon(resizedIcon);
		
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				UlazUapp window = new UlazUapp();
				window.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog
			}
		});
		btn.setBounds(0, 34, 89, 23);
		panel.add(btn);
		
		JButton btnNewButton_3 = new JButton("PREGLED REZERVACIJA");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					String upit="SELECT r.broj_rezervacije, r.datum, r.vrijeme, r.naziv_rezervacije, r.br_osoba, r.broj_stola, k.korisnicko_ime, r.posebne_napomene\r\n"
							+ "FROM rezervacija r\r\n"
							+ "JOIN konobar k ON r.sifra_konobara=k.sifra_konobara";
					
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery(upit);
					
					DefaultTableModel model=(DefaultTableModel)tablica.getModel();
					model.setRowCount(0);
					
					while (rs.next())
					{
						String br_rez=rs.getString("broj_rezervacije");
						String datum=rs.getString("datum");
						String vrijeme=rs.getString("vrijeme");
						String naziv_rezervacije=rs.getString("naziv_rezervacije");
						String br_osoba=rs.getString("br_osoba");
						String broj_stola=rs.getString("broj_stola");
						String konobar=rs.getString("korisnicko_ime");
						String napomena=rs.getString("posebne_napomene");
						
						model.addRow(new Object[] {br_rez, datum, vrijeme, naziv_rezervacije, br_osoba, broj_stola, konobar, napomena});
					}

					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,"Serverska greška." +e1);
				}
				
			}
		});
		btnNewButton_3.setBounds(925, 280, 170, 23);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Briši");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel model =(DefaultTableModel)tablica.getModel();
				int odabraniRedak=tablica.getSelectedRow();
				
				if(odabraniRedak>=0)
				{
					try
					{
						String br_rez=(String)tablica.getValueAt(odabraniRedak, 0);
						String datum=(String)tablica.getValueAt(odabraniRedak, 1);
						String vrijeme=(String)tablica.getValueAt(odabraniRedak, 2);
						String naziv=(String)tablica.getValueAt(odabraniRedak, 3);
						String br_osoba=(String)tablica.getValueAt(odabraniRedak, 4);
						String br_stola=(String)tablica.getValueAt(odabraniRedak, 5);
						String sifra=(String)tablica.getValueAt(odabraniRedak, 6);
						String napomena=(String)tablica.getValueAt(odabraniRedak, 7);
						
						Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
						Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

						String upit="DELETE rezervacija\r\n"
								+ "FROM rezervacija\r\n"
								+ "JOIN konobar ON rezervacija.sifra_konobara = konobar.sifra_konobara\r\n"
								+ "WHERE broj_rezervacije=? AND datum=? AND vrijeme=? AND naziv_rezervacije=? AND br_osoba=? AND broj_stola=? AND korisnicko_ime=? AND posebne_napomene=?";
						PreparedStatement ps= con.prepareStatement(upit);
						ps.setString(1, br_rez);
						ps.setString(2, datum);
						ps.setString(3, vrijeme);
						ps.setString(4, naziv);
						ps.setString(5, br_osoba);
						ps.setString(6, br_stola);
						ps.setString(7, sifra);
						ps.setString(8, napomena);
						
						int rezultat=ps.executeUpdate();
						
						if(rezultat==1)
						{
							DefaultTableModel model1=(DefaultTableModel)tablica.getModel();
							model1.removeRow(odabraniRedak);
							JOptionPane.showMessageDialog(null, "Rezervacija je uspješno izbrisana.");

						}
						else
						{
							JOptionPane.showMessageDialog(null, "Rezervaciju nije moguće izbrisati.");
						}
					}
					catch(Exception e1)
					{
					JOptionPane.showMessageDialog(null, "Serverska greška." +e1);
					}
				}
					else
					{
						JOptionPane.showMessageDialog(null, "Odaberite redak!");
					}

			}
		});
		btnNewButton_4.setBounds(943, 357, 89, 23);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_6 = new JButton("Izmijeni");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//frame.setBounds(100, 100, 1118, 800);
				String datums=datum.getText();
				String vrijemes=vrijeme.getText();
				String nazivs=naziv.getText();
				String brOsobas=brOsoba.getText();
				
				String odabraniKonobar=(String)comboKonobar.getSelectedItem();//objekt pretvaramo u string
				String odabraniStol=(String)comboStol.getSelectedItem();//isto kao toString funkcija
				
				String napomenas=napomena.getText();
				
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");
////////////////////
					//// šifru povuć sa selektom i spremiti u varijablu.
					String strUpit = "SELECT sifra_konobara FROM konobar WHERE korisnicko_ime = '"+odabraniKonobar+"'";
					Statement stmt3=con.createStatement();
					ResultSet rs3=stmt3.executeQuery(strUpit);
					
					int odabranasifrakonobara=0;					
					
					if(rs3.next())//u retku trazimo selektirani clan
					{
						odabranasifrakonobara=rs3.getInt(1);
					}
					 //upit spremiti u odabranasifrakonobara
//////////////////////////////////////					
					String upit1="UPDATE rezervacija  SET datum=?, vrijeme=?, naziv_rezervacije=?, br_osoba=?, broj_stola=?, sifra_konobara=?, posebne_napomene=? WHERE broj_rezervacije=?";
					
					PreparedStatement ps=con.prepareStatement(upit1);
					
					
					ps.setString(1, datums);
					ps.setString(2, vrijemes);
					ps.setString(3, nazivs);
					ps.setString(4, brOsobas);
					ps.setString(5, odabraniStol);
					ps.setInt(6, odabranasifrakonobara);
					ps.setString(7, napomenas);
					ps.setInt(8, broj_rezervacije);
				
					
					
					
					int updateRedak=ps.executeUpdate();
					
					
					if(updateRedak > 0)
					{
						
						JOptionPane.showMessageDialog(null, "Rezervacija je uspiješno ažurirana.");
						
						datum.setText("");
						vrijeme.setText("");
						naziv.setText("");
						datum.setText("");
						brOsoba.setText("");
						napomena.setText("");
						
					}
					else 
					{
		                JOptionPane.showMessageDialog(null, "Pokušaj izmjene nije uspio.");
		            }
					
					String upit="SELECT r.broj_rezervacije, r.datum, r.vrijeme, r.naziv_rezervacije, r.br_osoba, r.broj_stola, k.korisnicko_ime, r.posebne_napomene\r\n"
							+ "FROM rezervacija r\r\n"
							+ "JOIN konobar k ON r.sifra_konobara=k.sifra_konobara";
					
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery(upit);
					
					DefaultTableModel model=(DefaultTableModel)tablica.getModel();
					model.setRowCount(0);
					
					while (rs.next())
					{
						String br_rez=rs.getString("broj_rezervacije");
						String datum=rs.getString("datum");
						String vrijeme=rs.getString("vrijeme");
						String naziv_rezervacije=rs.getString("naziv_rezervacije");
						String br_osoba=rs.getString("br_osoba");
						String broj_stola=rs.getString("broj_stola");
						String konobar=rs.getString("korisnicko_ime");
						String napomena=rs.getString("posebne_napomene");
						
						model.addRow(new Object[] {br_rez, datum, vrijeme, naziv_rezervacije, br_osoba, broj_stola, konobar, napomena});
					}
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Serverska greška." +e1);
					System.out.println(e1);
				}
				
			}
		});
		btnNewButton_6.setBounds(943, 323, 89, 23);
		panel.add(btnNewButton_6);
		
		JLabel lblNewLabel_4 = new JLabel("*Datum tipa: xx.xx.xxxx");
		lblNewLabel_4.setBounds(22, 178, 250, 14);
		panel.add(lblNewLabel_4);
	}
	
	public void showWindow() {
		frame.setVisible(true);
	}
}
