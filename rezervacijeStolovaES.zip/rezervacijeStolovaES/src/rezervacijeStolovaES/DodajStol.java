package rezervacijeStolovaES;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class DodajStol {

	public JFrame frame;
	private JTextField brStola;
	JButton btn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DodajStol window = new DodajStol();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DodajStol() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 486, 354);
		frame.getContentPane().setBackground(new Color(140, 190, 215));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Dodaj stol:");
		lblNewLabel_1.setFont(new Font("Corbel", Font.BOLD, 16));
		lblNewLabel_1.setBounds(190, 31, 89, 38);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Broj stola:");
		lblNewLabel.setBounds(201, 94, 67, 23);
		frame.getContentPane().add(lblNewLabel);
		
		brStola = new JTextField();
		brStola.setBounds(201, 128, 52, 37);
		frame.getContentPane().add(brStola);
		brStola.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Broj sjedećih mjesta:");
		lblNewLabel_2.setBounds(183, 168, 103, 21);
		frame.getContentPane().add(lblNewLabel_2);
		
		JTextField brMjesta = new JTextField();
		brMjesta.setColumns(10);
		brMjesta.setBounds(201, 200, 52, 37);
		frame.getContentPane().add(brMjesta);
		
		JButton btnNewButton = new JButton("DODAJ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String brStolas=brStola.getText();
				String brMjestas=brMjesta.getText();
				
				
				if(!brStolas.matches("[0-9]+"))
						{
					JOptionPane.showMessageDialog(null,  "U polje Broj stola moguće je unijeti samo brojeve!");
						}
				else if(!brMjestas.matches("[0-9]+"))
				{
			JOptionPane.showMessageDialog(null,  "U polje Broj mjesta moguće je unijeti samo brojeve!");
				}
				
				else 
				{
				try
				{
					int stolbr=Integer.parseInt(brStolas);
					int mjestobr=Integer.parseInt(brMjestas);
					
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					String upit="INSERT INTO stol(broj_stola, broj_mjesta) VALUES (?,?)";
					
					PreparedStatement ps=con.prepareStatement(upit);
					
					ps.setInt(1, stolbr);
					ps.setInt(2, mjestobr);
					
					int ubacenoRedaka=ps.executeUpdate();
					
					if(ubacenoRedaka==1)
					{
						JOptionPane.showMessageDialog(null, "Stol je uspješno unesen.");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Stol nije unesen. Molimo pokušajte ponovo.");
					}
				}
				catch (Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Greška na serveru." +e1);
				}
				}
			}
		});
		btnNewButton.setBounds(183, 262, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		
		ImageIcon slika= new ImageIcon("C:\\Users\\Ema\\Downloads\\nazad.png");
		Image originalImage = slika.getImage();
		btn = new JButton();
		
		int newWidth = 30;
        int newHeight = 25;
        
        Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
		//btn.setText("Bok");
		btn.setFocusable(false);
		btn.setIcon(resizedIcon);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Stolovi window = new Stolovi();
				window.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog
				
			}
		});
		btn.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(btn);
				
				

			
	}

}
