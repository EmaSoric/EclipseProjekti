package rezervacijeStolovaES;
import rezervacijeStolovaES.Login;
import rezervacijeStolovaES.Registracija;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Reg_log {

	public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reg_log window = new Reg_log();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Reg_log() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(140, 190, 215));
		frame.setBounds(100, 100, 492, 476);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("REGISTRACIJA");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Registracija window = new Registracija();
				window.frame.setVisible(true);
				frame.setVisible(false);

				
			}
		});
		btnNewButton.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 14));
		btnNewButton.setBounds(140, 109, 196, 74);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.setBackground(new Color(255, 255, 255));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login window = new Login();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnLogin.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 14));
		btnLogin.setBounds(140, 194, 196, 74);
		frame.getContentPane().add(btnLogin);
	}

	public void showWindow() {
		frame.setVisible(true);
	}
	
}
