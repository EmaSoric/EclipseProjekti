package rezervacijeStolovaES;

import rezervacijeStolovaES.GlavniMenu;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;



import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class KonobariMenu {

	public JFrame frame; //prozor smo morali staviti na public kako bi nam ostatak aplikacije moga upravljati prozorima
	private JTextField trazi;
	private JTable tablica;
	private JTextField ime;
	private JTextField prezime;
	private JTextField br_mob;
	private int sifra_konobara;
	JButton btn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					KonobariMenu window = new KonobariMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public KonobariMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1118, 577);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(140, 190, 215));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("REZERVACIJE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				GlavniMenu glavniMenu = new GlavniMenu();
				glavniMenu.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog, zato smo morali frame na vrhu staviti public umjesto private
				}
				
			
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Corbel", Font.BOLD, 18));
		btnNewButton.setBounds(0, 0, 496, 45);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("KONOBARI");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Corbel", Font.BOLD, 18));
		lblNewLabel.setBounds(494, 0, 505, 45);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Pregled konobara:");
		lblNewLabel_1.setFont(new Font("Corbel", Font.BOLD, 16));
		lblNewLabel_1.setBounds(29, 71, 227, 38);
		panel.add(lblNewLabel_1);
		
		trazi = new JTextField();
		trazi.setBounds(177, 78, 250, 20);
		panel.add(trazi);
		trazi.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("TRAŽI");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String trazis=trazi.getText();
				
				
				try
				{
					
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					String upit="SELECT k.sifra_konobara, k.ime, k.prezime, k.korisnicko_ime, k.br_mob FROM konobar k WHERE sifra_konobara LIKE ? OR ime LIKE ? OR prezime LIKE ? OR korisnicko_ime LIKE ? OR br_mob LIKE ?"; 
					
					PreparedStatement ps=con.prepareStatement(upit);
					ps.setString(1, "%" +trazis+ "%");
					ps.setString(2, "%" +trazis+ "%");
					ps.setString(3, "%" +trazis+ "%");
					ps.setString(4, "%" +trazis+ "%");
					ps.setString(5, "%" +trazis+ "%");
					
					ResultSet rs=ps.executeQuery();
					
					DefaultTableModel model=(DefaultTableModel)tablica.getModel();
					
					model.setRowCount(0);
					
					while(rs.next())
					{
						int sifra_konobara=rs.getInt(1);
						String ime=rs.getString(2);
						String prezime=rs.getString(3);
						String korisnicko_ime=rs.getString(4);
						String br_mob=rs.getString(5);
						
						model.addRow(new Object[] {sifra_konobara, ime, prezime, korisnicko_ime, br_mob});
						
						
					}
					
				}
				catch (Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Serverska greška." +e1);
				}
			}
		});
		btnNewButton_1.setBounds(437, 77, 89, 23);
		panel.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(45, 147, 580, 384);
		panel.add(scrollPane);
		
		tablica = new JTable();
		tablica.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				int odabraniRedak=tablica.getSelectedRow();
				ime.setText(tablica.getValueAt(odabraniRedak, 1).toString());
				prezime.setText(tablica.getValueAt(odabraniRedak, 2).toString());
				br_mob.setText(tablica.getValueAt(odabraniRedak, 4).toString());
				sifra_konobara=Integer.parseInt(tablica.getValueAt(odabraniRedak, 0).toString());
				
				
			}
		});
		scrollPane.setViewportView(tablica);
		tablica.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID konobara", "Ime", "Prezime", "Korisnicko ime", "Mobitel"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tablica.getColumnModel().getColumn(0).setPreferredWidth(40);
		
		JButton btnNewButton_2 = new JButton("DODAJ");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Registracija2 window = new Registracija2();
				window.frame.setVisible(true);
				frame.setVisible(false);
				//zatvara nam se prozor prilikom otvaranja novog, zato smo morali frame na vrhu staviti public umjesto private
				}
			
			
		});
		btnNewButton_2.setBounds(630, 170, 89, 23);
		panel.add(btnNewButton_2);
		
		ImageIcon slika= new ImageIcon("C:\\Users\\Ema\\Downloads\\nazad.png");
		Image originalImage = slika.getImage();
		btn = new JButton();
		
		int newWidth = 30;
        int newHeight = 25;
        
        Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
        
        btn.setFocusable(false);
		btn.setIcon(resizedIcon);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				UlazUapp window = new UlazUapp();
				window.frame.setVisible(true);
				frame.setVisible(false);//zatvara nam se prozor prilikom otvaranja novog
			}
		});
		btn.setBounds(0, 43, 89, 23);
		panel.add(btn);
		
		JButton btnNewButton_6 = new JButton("PREGLED KONOBARA");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					String upit="SELECT k.sifra_konobara, k.ime, k.prezime, k.korisnicko_ime, k.br_mob FROM konobar k";
					
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery(upit);
					
					DefaultTableModel model=(DefaultTableModel)tablica.getModel();
					model.setRowCount(0);//svaki put kada stisnemo gumbić se tablica postavlja na nulu
					
					while(rs.next())
					{
						String sifra=rs.getString(1);
						String ime=rs.getString(2); //jer je to drugi stupac u tablici, ili mozemo staviti navodnike i u njih naziv atributa iz tablice
						String prezime=rs.getString(3);
						String kor_ime=rs.getString(4);
						String br_mob=rs.getString(5);
						
						
						model.addRow(new Object[] {sifra, ime, prezime, kor_ime, br_mob});
						
				
					}
				}

				
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		btnNewButton_6.setBounds(463, 124, 160, 23);
		panel.add(btnNewButton_6);
		
		JLabel lblNewLabel_2 = new JLabel("Izmijeni podatke o konobaru:");
		lblNewLabel_2.setFont(new Font("Corbel", Font.BOLD, 14));
		lblNewLabel_2.setBounds(818, 154, 200, 20);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Ime:");
		lblNewLabel_3.setFont(new Font("Corbel", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(828, 179, 150, 14);
		panel.add(lblNewLabel_3);
		
		ime = new JTextField();
		ime.setBounds(818, 204, 150, 20);
		panel.add(ime);
		ime.setColumns(10);
		
		JLabel lblNewLabel_3_1 = new JLabel("Prezime:");
		lblNewLabel_3_1.setFont(new Font("Corbel", Font.PLAIN, 12));
		lblNewLabel_3_1.setBounds(828, 247, 150, 14);
		panel.add(lblNewLabel_3_1);
		
		prezime = new JTextField();
		prezime.setColumns(10);
		prezime.setBounds(818, 272, 150, 20);
		panel.add(prezime);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Broj mobitela:");
		lblNewLabel_3_1_1.setFont(new Font("Corbel", Font.PLAIN, 12));
		lblNewLabel_3_1_1.setBounds(828, 310, 150, 14);
		panel.add(lblNewLabel_3_1_1);
		
		br_mob = new JTextField();
		br_mob.setColumns(10);
		br_mob.setBounds(818, 335, 150, 20);
		panel.add(br_mob);
		
		JButton btnNewButton_4 = new JButton("IZMJENI");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String imes=ime.getText();
				String prezimes=prezime.getText();
				String br_mobs=br_mob.getText();
				//int sifra_konobara=; //?
				
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
					Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

					String upit1="UPDATE konobar SET ime=?, prezime=?, br_mob=? WHERE sifra_konobara=?";
					
					PreparedStatement ps=con.prepareStatement(upit1);
					
					ps.setString(1, imes);
					ps.setString(2, prezimes);
					ps.setString(3, br_mobs);
					ps.setInt(4, sifra_konobara);
					
					
					
					int updateRedak=ps.executeUpdate();
					ime.setText("");
					prezime.setText("");
					br_mob.setText("");
					
					if(updateRedak > 0)
					{
						
						JOptionPane.showMessageDialog(null, "Konobar je uspiješno ažuriran.");
						
					}
					else 
					{
		                JOptionPane.showMessageDialog(null, "Pokušaj izmjene nije uspio.");
		            }
					
					String upit="SELECT k.sifra_konobara, k.ime, k.prezime, k.korisnicko_ime, k.br_mob FROM konobar k";
					
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery(upit);
					
					DefaultTableModel model=(DefaultTableModel)tablica.getModel();
					model.setRowCount(0);//svaki put kada stisnemo gumbić se tablica postavlja na nulu
					
					while(rs.next())
					{
						String sifra=rs.getString(1);
						String ime=rs.getString(2); //jer je to drugi stupac u tablici, ili mozemo staviti navodnike i u njih naziv atributa iz tablice
						String prezime=rs.getString(3);
						String kor_ime=rs.getString(4);
						String br_mob=rs.getString(5);
						
						
						model.addRow(new Object[] {sifra, ime, prezime, kor_ime, br_mob});
						
				
					}
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, "Serverska greška." +e1);
				}
			}
		});
		btnNewButton_4.setBounds(841, 376, 100, 23);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_2_1 = new JButton("BRIŠI");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				DefaultTableModel model=(DefaultTableModel)tablica.getModel();
				
				int odabraniRedak=tablica.getSelectedRow();
				
				if(odabraniRedak>=0)
				{
					try
					{
						String sifra_konobara=(String)tablica.getValueAt(odabraniRedak, 0);
						String ime=(String)tablica.getValueAt(odabraniRedak, 1);
						String prezime=(String)tablica.getValueAt(odabraniRedak, 2);
						String korisnicko_ime=(String)tablica.getValueAt(odabraniRedak, 3);
						String br_mob=(String)tablica.getValueAt(odabraniRedak, 4);
						
						//nakon što smo označili redak i njegove vrijednosti
						//sada brisemo iz baze
						
						Class.forName("com.mysql.cj.jdbc.Driver");//driver za spajanje na bazu, server je na webu baza je mysql...
						Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/esoric?serverTimezone=UTC", "esoric", "11");

						String upit="DELETE FROM konobar WHERE sifra_konobara=? AND ime=? AND prezime=? AND korisnicko_ime=? AND br_mob=?";
						PreparedStatement ps=con.prepareStatement(upit);
						ps.setString(1, sifra_konobara);
						ps.setString(2, ime);
						ps.setString(3, prezime);
						ps.setString(4, korisnicko_ime);
						ps.setString(5, br_mob);
						
						int rezultat=ps.executeUpdate();
						
						if(rezultat==1)
						{
							DefaultTableModel model1=(DefaultTableModel)tablica.getModel();
							model1.removeRow(odabraniRedak);
							JOptionPane.showMessageDialog(null, "Konobar je uspješno izbrisan.");
							
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Konobara nije moguće izbrisati.");
						}
						
					}
					catch(Exception e1)
					{
						JOptionPane.showMessageDialog(null, "Konobar kojeg želite obrisati ima unesene rezervacije, te ga zbog toga nije moguće obrisati.");
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Odaberite redak.");
				}
			}
		});
		btnNewButton_2_1.setBounds(630, 215, 89, 23);
		panel.add(btnNewButton_2_1);
	}
}
